# DIV Record

Extensao de navegador para Chrome/Edge que permite selecionar elementos diretamente na pagina e salvar um print ja recortado, sem precisar editar a imagem depois.

## Como usar

1. Abra `chrome://extensions` no Chrome ou `edge://extensions` no Edge.
2. Ative o **Modo do desenvolvedor**.
3. Clique em **Carregar sem compactação** e selecione esta pasta:
   - `C:\Users\jonat\Documents\div-record`
4. Abra a página que deseja capturar.
5. Clique no icone da extensao e depois em **Selecionar elemento**.
6. Passe o mouse pela pagina para destacar o elemento.
7. Use a roda do mouse ou as setas para subir e descer na hierarquia do container.
8. Clique no elemento desejado para gerar e baixar o print.

## O que a extensão faz

- Destaca o elemento sob o cursor.
- Permite navegar na hierarquia do container antes de capturar.
- Suporta `div`, `section`, `article`, `main`, `button`, `canvas`, `svg`, `img` e outros elementos comuns.
- Adiciona margem configuravel ao redor da captura.
- Esconde o destaque visual antes de salvar a imagem.
- Captura elementos maiores que a viewport em várias partes e costura o resultado.
- Pode copiar a imagem para a area de transferencia.
- Faz o recorte automaticamente e baixa um `.png`.

## Limitação importante

A API padrão de extensões captura a área visível da aba, então a extensão percorre a página em múltiplos screenshots quando a `div` é maior que a janela. Ainda podem existir diferenças em sites com cabeçalhos fixos, animações ou conteúdo que muda durante a rolagem.
