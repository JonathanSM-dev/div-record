const state = {
  selectionActive: false,
  hoveredElement: null,
  selectedElement: null,
  overlay: null,
  label: null,
  toast: null,
  toastTimer: null,
  captureSession: null
};

function ensureOverlay() {
  if (state.overlay) {
    return;
  }

  const overlay = document.createElement("div");
  overlay.id = "__div_record_overlay__";
  overlay.style.position = "fixed";
  overlay.style.left = "0";
  overlay.style.top = "0";
  overlay.style.width = "0";
  overlay.style.height = "0";
  overlay.style.pointerEvents = "none";
  overlay.style.zIndex = "2147483646";
  overlay.style.border = "2px solid #0d6efd";
  overlay.style.background = "rgba(13, 110, 253, 0.12)";
  overlay.style.boxShadow = "0 0 0 99999px rgba(7, 16, 35, 0.2)";
  overlay.style.transition = "all 60ms ease";

  const label = document.createElement("div");
  label.style.position = "fixed";
  label.style.pointerEvents = "none";
  label.style.zIndex = "2147483647";
  label.style.padding = "6px 8px";
  label.style.borderRadius = "8px";
  label.style.fontFamily = "Segoe UI, sans-serif";
  label.style.fontSize = "12px";
  label.style.fontWeight = "600";
  label.style.color = "#ffffff";
  label.style.background = "#0d6efd";
  label.style.boxShadow = "0 6px 14px rgba(0, 0, 0, 0.18)";
  label.textContent = "Selecione uma div";

  document.documentElement.appendChild(overlay);
  document.documentElement.appendChild(label);

  state.overlay = overlay;
  state.label = label;
}

function hideOverlay() {
  if (!state.overlay || !state.label) {
    return;
  }

  state.overlay.style.width = "0";
  state.overlay.style.height = "0";
  state.label.style.opacity = "0";
}

function setOverlayVisibility(visible) {
  if (!state.overlay || !state.label) {
    return;
  }

  state.overlay.style.display = visible ? "block" : "none";
  state.label.style.display = visible ? "block" : "none";
}

function describeElement(element) {
  const tag = element.tagName.toLowerCase();
  const id = element.id ? `#${element.id}` : "";
  const classes = Array.from(element.classList).slice(0, 2).join(".");
  const classSuffix = classes ? `.${classes}` : "";
  return `${tag}${id}${classSuffix}`;
}

function updateOverlay(element) {
  ensureOverlay();

  const rect = element.getBoundingClientRect();
  state.overlay.style.left = `${rect.left}px`;
  state.overlay.style.top = `${rect.top}px`;
  state.overlay.style.width = `${rect.width}px`;
  state.overlay.style.height = `${rect.height}px`;

  state.label.textContent = `Capturar ${describeElement(element)}`;
  state.label.style.opacity = "1";
  state.label.style.left = `${Math.max(8, rect.left)}px`;
  state.label.style.top = `${Math.max(8, rect.top - 34)}px`;
}

function findSelectableDiv(target) {
  if (!(target instanceof Element)) {
    return null;
  }

  const div = target.closest("div");

  if (!div) {
    return null;
  }

  if (div === document.documentElement || div === document.body) {
    return null;
  }

  const rect = div.getBoundingClientRect();

  if (rect.width < 4 || rect.height < 4) {
    return null;
  }

  return div;
}

function clearToast() {
  if (state.toastTimer) {
    clearTimeout(state.toastTimer);
    state.toastTimer = null;
  }

  if (state.toast) {
    state.toast.remove();
    state.toast = null;
  }
}

function showToast(message, isError = false) {
  clearToast();

  const toast = document.createElement("div");
  toast.id = "__div_record_toast__";
  toast.textContent = message;
  toast.style.position = "fixed";
  toast.style.right = "16px";
  toast.style.bottom = "16px";
  toast.style.zIndex = "2147483647";
  toast.style.padding = "12px 14px";
  toast.style.borderRadius = "12px";
  toast.style.font = "600 13px Segoe UI, sans-serif";
  toast.style.color = "#ffffff";
  toast.style.background = isError ? "#b42318" : "#101828";
  toast.style.boxShadow = "0 12px 24px rgba(0, 0, 0, 0.2)";

  document.documentElement.appendChild(toast);
  state.toast = toast;
  state.toastTimer = window.setTimeout(() => clearToast(), 2600);
}

function stopSelection() {
  state.selectionActive = false;
  state.hoveredElement = null;
  hideOverlay();
}

function startSelection() {
  ensureOverlay();
  setOverlayVisibility(true);
  state.selectionActive = true;
  state.selectedElement = null;
  showToast("Modo de selecao ativo. Clique na div desejada.");
}

function onMouseMove(event) {
  if (!state.selectionActive) {
    return;
  }

  const element = findSelectableDiv(event.target);

  if (!element) {
    state.hoveredElement = null;
    hideOverlay();
    return;
  }

  state.hoveredElement = element;
  updateOverlay(element);
}

function onClick(event) {
  if (!state.selectionActive) {
    return;
  }

  event.preventDefault();
  event.stopPropagation();

  const element = findSelectableDiv(event.target);

  if (!element) {
    showToast("Nenhuma div valida encontrada nesse ponto.", true);
    return;
  }

  state.selectedElement = element;
  state.selectionActive = false;
  updateOverlay(element);
  clearToast();

  chrome.runtime.sendMessage({
    type: "CAPTURE_ELEMENT",
    payload: {
      selectorLabel: describeElement(element)
    }
  }, (response) => {
    if (chrome.runtime.lastError) {
      showToast(chrome.runtime.lastError.message, true);
      return;
    }

    if (!response?.ok) {
      showToast(response?.error || "Falha ao capturar a div.", true);
    }
  });
}

function onKeyDown(event) {
  if (!state.selectionActive) {
    return;
  }

  if (event.key === "Escape") {
    stopSelection();
    showToast("Selecao cancelada.");
  }
}

async function prepareCapture() {
  const element = state.selectedElement;

  if (!element || !document.contains(element)) {
    throw new Error("A div selecionada nao esta mais disponivel.");
  }

  state.captureSession = {
    scrollX: window.scrollX,
    scrollY: window.scrollY
  };

  clearToast();
  setOverlayVisibility(false);

  const rect = element.getBoundingClientRect();

  return {
    ok: true,
    metrics: {
      left: rect.left + window.scrollX,
      top: rect.top + window.scrollY,
      width: Math.max(1, rect.width),
      height: Math.max(1, rect.height),
      viewportWidth: window.innerWidth,
      viewportHeight: window.innerHeight,
      devicePixelRatio: window.devicePixelRatio || 1,
      label: describeElement(element)
    }
  };
}

async function scrollForCapture(payload) {
  window.scrollTo({
    left: payload.x,
    top: payload.y,
    behavior: "auto"
  });

  await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)));

  return {
    ok: true,
    viewport: {
      left: window.scrollX,
      top: window.scrollY
    }
  };
}

function restoreAfterCapture() {
  if (state.captureSession) {
    window.scrollTo({
      left: state.captureSession.scrollX,
      top: state.captureSession.scrollY,
      behavior: "auto"
    });
  }

  state.captureSession = null;
  hideOverlay();
  setOverlayVisibility(true);
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "START_SELECTION") {
    startSelection();
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === "PREPARE_CAPTURE") {
    prepareCapture()
      .then(sendResponse)
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error.message || "Falha ao preparar a captura."
        });
      });
    return true;
  }

  if (message?.type === "SCROLL_FOR_CAPTURE") {
    scrollForCapture(message.payload)
      .then(sendResponse)
      .catch((error) => {
        sendResponse({
          ok: false,
          error: error.message || "Falha ao posicionar a pagina."
        });
      });
    return true;
  }

  if (message?.type === "CAPTURE_COMPLETE") {
    restoreAfterCapture();
    showToast("Print salvo com sucesso.");
    sendResponse({ ok: true });
    return false;
  }

  if (message?.type === "CAPTURE_FAILED") {
    restoreAfterCapture();
    showToast(message.error || "Erro ao capturar a div.", true);
    sendResponse({ ok: true });
    return false;
  }

  return false;
});

document.addEventListener("mousemove", onMouseMove, true);
document.addEventListener("click", onClick, true);
document.addEventListener("keydown", onKeyDown, true);
