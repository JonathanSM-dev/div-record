const startButton = document.getElementById("start-selection");
const statusElement = document.getElementById("status");

function setStatus(message, isError = false) {
  statusElement.textContent = message;
  statusElement.style.color = isError ? "#b42318" : "#1357d4";
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

startButton.addEventListener("click", async () => {
  startButton.disabled = true;
  setStatus("Ativando seleção na página...");

  try {
    const tab = await getActiveTab();

    if (!tab?.id) {
      throw new Error("Não encontrei a aba ativa.");
    }

    await chrome.tabs.sendMessage(tab.id, { type: "START_SELECTION" });
    setStatus("Passe o mouse e clique na div que deseja capturar.");
    window.close();
  } catch (error) {
    setStatus(error.message || "Não foi possível iniciar a seleção.", true);
    startButton.disabled = false;
  }
});
