async function sendMessageToTab(tabId, message) {
  return chrome.tabs.sendMessage(tabId, message);
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function sanitizeFilename(name) {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "div";
}

function buildAxisStarts(start, size, viewportSize) {
  if (size <= viewportSize) {
    return [Math.round(start)];
  }

  const starts = [];
  const end = start + size;
  let cursor = start;

  while (cursor < end) {
    starts.push(Math.round(cursor));
    cursor += viewportSize;
  }

  const finalStart = Math.round(end - viewportSize);

  if (starts[starts.length - 1] !== finalStart) {
    starts.push(finalStart);
  }

  return Array.from(new Set(starts));
}

async function captureVisibleTab(windowId) {
  return chrome.tabs.captureVisibleTab(windowId, { format: "png" });
}

async function loadBitmap(dataUrl) {
  const response = await fetch(dataUrl);
  const blob = await response.blob();
  return createImageBitmap(blob);
}

async function stitchCapture(windowId, tabId, metrics) {
  const pixelRatio = metrics.devicePixelRatio || 1;
  const canvasWidth = Math.max(1, Math.round(metrics.width * pixelRatio));
  const canvasHeight = Math.max(1, Math.round(metrics.height * pixelRatio));
  const canvas = new OffscreenCanvas(canvasWidth, canvasHeight);
  const context = canvas.getContext("2d");

  const xStarts = buildAxisStarts(metrics.left, metrics.width, metrics.viewportWidth);
  const yStarts = buildAxisStarts(metrics.top, metrics.height, metrics.viewportHeight);

  for (const scrollY of yStarts) {
    for (const scrollX of xStarts) {
      const viewport = await sendMessageToTab(tabId, {
        type: "SCROLL_FOR_CAPTURE",
        payload: { x: scrollX, y: scrollY }
      });

      if (!viewport?.ok) {
        throw new Error(viewport?.error || "Falha ao posicionar a pagina para captura.");
      }

      await wait(120);

      const screenshotDataUrl = await captureVisibleTab(windowId);
      const bitmap = await loadBitmap(screenshotDataUrl);

      const viewportLeft = viewport.viewport.left;
      const viewportTop = viewport.viewport.top;
      const viewportRight = viewportLeft + metrics.viewportWidth;
      const viewportBottom = viewportTop + metrics.viewportHeight;

      const overlapLeft = Math.max(metrics.left, viewportLeft);
      const overlapTop = Math.max(metrics.top, viewportTop);
      const overlapRight = Math.min(metrics.left + metrics.width, viewportRight);
      const overlapBottom = Math.min(metrics.top + metrics.height, viewportBottom);
      const overlapWidth = overlapRight - overlapLeft;
      const overlapHeight = overlapBottom - overlapTop;

      if (overlapWidth <= 0 || overlapHeight <= 0) {
        continue;
      }

      const sourceX = Math.round((overlapLeft - viewportLeft) * pixelRatio);
      const sourceY = Math.round((overlapTop - viewportTop) * pixelRatio);
      const sourceWidth = Math.round(overlapWidth * pixelRatio);
      const sourceHeight = Math.round(overlapHeight * pixelRatio);
      const destX = Math.round((overlapLeft - metrics.left) * pixelRatio);
      const destY = Math.round((overlapTop - metrics.top) * pixelRatio);

      context.drawImage(
        bitmap,
        sourceX,
        sourceY,
        sourceWidth,
        sourceHeight,
        destX,
        destY,
        sourceWidth,
        sourceHeight
      );
    }
  }

  const blob = await canvas.convertToBlob({ type: "image/png" });
  const reader = new FileReader();

  return new Promise((resolve, reject) => {
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Falha ao converter o print final."));
    reader.readAsDataURL(blob);
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "CAPTURE_ELEMENT") {
    return false;
  }

  const tabId = sender.tab?.id;
  const windowId = sender.tab?.windowId;

  if (!tabId || !windowId) {
    sendResponse({ ok: false, error: "Aba invalida para captura." });
    return false;
  }

  (async () => {
    try {
      const prepared = await sendMessageToTab(tabId, {
        type: "PREPARE_CAPTURE",
        payload: message.payload
      });

      if (!prepared?.ok) {
        throw new Error(prepared?.error || "Falha ao preparar a captura.");
      }

      const finalDataUrl = await stitchCapture(windowId, tabId, prepared.metrics);
      const filename = `div-record-${sanitizeFilename(prepared.metrics.label)}-${Date.now()}.png`;

      await chrome.downloads.download({
        url: finalDataUrl,
        filename,
        saveAs: true
      });

      await sendMessageToTab(tabId, { type: "CAPTURE_COMPLETE" });
      sendResponse({ ok: true, filename });
    } catch (error) {
      await sendMessageToTab(tabId, {
        type: "CAPTURE_FAILED",
        error: error.message || "Erro ao capturar a div."
      }).catch(() => {});

      sendResponse({
        ok: false,
        error: error.message || "Erro ao capturar a div."
      });
    }
  })();

  return true;
});
