# DIV Record

Extensão de navegador para Chrome/Edge que permite selecionar uma `div` diretamente na página e salvar um print já recortado, sem precisar editar a imagem depois.

## Como usar

1. Abra `chrome://extensions` no Chrome ou `edge://extensions` no Edge.
2. Ative o **Modo do desenvolvedor**.
3. Clique em **Carregar sem compactação** e selecione esta pasta:
   - `C:\Users\jonat\Documents\div-record`
4. Abra a página que deseja capturar.
5. Clique no ícone da extensão e depois em **Selecionar div**.
6. Passe o mouse pela página para destacar a `div`.
7. Clique na `div` desejada para gerar e baixar o print.

## O que a extensão faz

- Destaca a `div` sob o cursor.
- Seleciona automaticamente a `div` ancestral mais próxima do ponto clicado.
- Esconde o destaque visual antes de salvar a imagem.
- Captura elementos maiores que a viewport em várias partes e costura o resultado.
- Faz o recorte automaticamente e baixa um `.png`.

## Limitação importante

A API padrão de extensões captura a área visível da aba, então a extensão percorre a página em múltiplos screenshots quando a `div` é maior que a janela. Ainda podem existir diferenças em sites com cabeçalhos fixos, animações ou conteúdo que muda durante a rolagem.
